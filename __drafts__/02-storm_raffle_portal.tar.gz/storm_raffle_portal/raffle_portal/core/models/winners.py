from django.db import models
from django.contrib.auth.models import User
from core.models.raffles import Raffle


class WinnerNotification(models.Model):
    raffle = models.OneToOneField(Raffle, on_delete=models.CASCADE)
    winner = models.ForeignKey(User, on_delete=models.CASCADE)
    mobile_prefix = models.PositiveIntegerField(placeholder="11")
    mobile_number = models.CharField(max_length=11, placeholder="94669-9296")
    notified_at = models.DateTimeField(auto_now_add=True)
