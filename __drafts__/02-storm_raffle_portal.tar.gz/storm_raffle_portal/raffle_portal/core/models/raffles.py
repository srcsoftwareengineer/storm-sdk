from django.db import models
from django.contrib.auth.models import User


class Raffle(models.Model):
    STATUS_CHOICES = [
        ('draft', 'Draft'),
        ('published', 'Published'),
        ('finished', 'Finished'),
    ]
    title = models.CharField(max_length=200)
    description = models.TextField()
    draw_date = models.DateField()  # schedule draw date
    created_by = models.ForeignKey(User, on_delete=models.CASCADE)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='draft')
    total_tickets = models.PositiveIntegerField(default=100)  # i.e: matrix(5, 20)
    drawn_at = models.DateTimeField(null=True, blank=True)  # ran
